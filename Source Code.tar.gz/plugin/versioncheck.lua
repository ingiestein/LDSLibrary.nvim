if vim.fn.has("nvim-0.7.0") ~= 1 then
	vim.api.nvim_err_write("This plugin requires nvim-0.7.0 or higher.")
end
